public class GradeBook{
	public void printMessage(){
		System.out.println("Welcome");
	}
}