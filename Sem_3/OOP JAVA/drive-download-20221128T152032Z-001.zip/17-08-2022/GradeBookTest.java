public class GradeBookTest{
	public static void main(String[] args){
	
		GradeBook g = new GradeBook();
		g.printMessage();
	}
}